

#______COMMANDS 
#pkg update 

# pkg upgrade 

# pkg install git 

# pkg install python  

# pkg install python2  

# pip2 install requests 

# pip2 install mechanize  

 RANA MZ
# ☠ RUN SCRIPT